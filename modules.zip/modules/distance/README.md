# metric_distance
A templated, header only C++14 implementation of a Metric Distance Functions. 

