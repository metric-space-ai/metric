# Clone and build

After cloning repository run next command to update submodules:

`$ git submodule init
 $ git submodule update`
 
 
