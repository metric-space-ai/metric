#include "details/matrix.hpp"
#include "details/graph.hpp"
#include "details/tree.hpp"
