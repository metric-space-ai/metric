/* 
This Source Code Form is subject to the terms of the Mozilla Public
License, v. 2.0. If a copy of the MPL was not distributed with this
file, You can obtain one at http://mozilla.org/MPL/2.0/.

Signal Empowering Technology ®Michael Welsch
*/

#ifndef _METRIC_SPACE_MATRIX_HPP
#define _METRIC_SPACE_MATRIX_HPP


#include "matrix.cpp"

#endif // headerguard